Assemblr 1.0.0 - sample files for review

sample-bottle.png, sample-can.png, sample-box.png, sample-jar.png, sample-tube.png
  Five product cut-outs with transparent backgrounds. Each file has a different
  amount of transparent space round its product, so their frames do not line up
  with the products themselves. Assemblr arranges them by the visible product.

sample-badge.png
  A badge for a corner of a product (Overlays tile, Load badge...).

All images were drawn for this purpose and carry no third-party brands.
